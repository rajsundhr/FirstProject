
public class Main {

	public static void main(String[] args) {
		BankingApp bankingapp = new BankingApp();
		bankingapp.banking();

	}

}
